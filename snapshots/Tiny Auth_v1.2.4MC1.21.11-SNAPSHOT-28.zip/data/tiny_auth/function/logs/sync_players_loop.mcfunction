data modify storage tiny_auth:temp control_panel.payload set value {}
data modify storage tiny_auth:temp control_panel.payload.player set from storage tiny_auth:temp control_panel.scan[0].player

$execute unless data storage tiny_auth:storage unique_players[{name:"$(player)"}] run data modify storage tiny_auth:storage unique_players append value {name:"$(player)"}

data remove storage tiny_auth:temp control_panel.scan[0]
execute if data storage tiny_auth:temp control_panel.scan[0] run function tiny_auth:logs/sync_players_loop with storage tiny_auth:temp control_panel
