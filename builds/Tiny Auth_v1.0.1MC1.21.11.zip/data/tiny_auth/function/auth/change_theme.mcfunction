scoreboard players reset @s tinyauth.auth.change_theme

execute store result storage tiny_auth:temp change_theme.theme_id int 1 run scoreboard players add @s tinyauth.auth.theme_id 1
data modify storage tiny_auth:temp change_theme.UUID set from entity @s UUID

function tiny_auth:auth/change_theme/macro with storage tiny_auth:temp change_theme
