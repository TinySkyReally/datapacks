$execute unless entity @a[name=$(Name)] run tellraw @s [{text:"This player isn't online, If this player has changed its name then the system might not have that name updated!",color:"red"}]

$data modify storage tiny_auth:keys auths[{Name:"$(Name)"}].password set value ""

$tellraw @s [{text:"Successfully reset player $(Name) password!",color:"green"}]
