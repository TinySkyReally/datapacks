scoreboard players reset @s tinyauth.auth.clear

function tiny_auth:auth/reset_input with entity @s

$data modify storage tiny_auth:temp initClear set value {UUID:$(UUID),message:"cleared",submit:-1,state:1}
execute store result storage tiny_auth:temp initClear.state int 1 run scoreboard players get @s tinyauth.auth.state

function tiny_auth:auth/init with storage tiny_auth:temp initClear
