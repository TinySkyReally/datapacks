# English (US)
data modify storage tiny_auth:languages en-us set value {blocked:{"text":"Your account is blocked, please wait!","color":"red"}, length_limit:{"text":"Password exceeded length limit!","color":"red"}, empty:{"text":"Password cannot be empty!","color":"red"}, cleared:{"text":"Cleared input.","color":"green"}, wrong:{"text":"Wrong password!","color":"red"}}

# Spanish (es-es)
data modify storage tiny_auth:languages es-es set value {blocked:{"text":"¡Tu cuenta está bloqueada, por favor espera!","color":"red"}, length_limit:{"text":"¡La contraseña excede el límite de caracteres!","color":"red"}, empty:{"text":"¡La contraseña no puede estar vacía!","color":"red"}, cleared:{"text":"Entrada borrada.","color":"green"}, wrong:{"text":"¡Contraseña incorrecta!","color":"red"}}

# French (fr-fr)
data modify storage tiny_auth:languages fr-fr set value {blocked:{"text":"Votre compte est bloqué, veuillez patienter !","color":"red"}, length_limit:{"text":"La mot de passe dépasse la limite!","color":"red"}, empty:{"text":"Le mot de passe ne peut pas être vide !","color":"red"}, cleared:{"text":"Saisie effacée.","color":"green"}, wrong:{"text":"Mauvais mot de passe !","color":"red"}}

# German (de-de)
data modify storage tiny_auth:languages de-de set value {blocked:{"text":"Dein Konto ist gesperrt, bitte warten!","color":"red"}, length_limit:{"text":"Passwort überschreitet das Limit!","color":"red"}, empty:{"text":"Passwort darf nicht leer sein!","color":"red"}, cleared:{"text":"Eingabe gelöscht.","color":"green"}, wrong:{"text":"Falsches Passwort!","color":"red"}}

# Portuguese (pt-br)
data modify storage tiny_auth:languages pt-br set value {blocked:{"text":"Sua conta está bloqueada, aguarde!","color":"red"}, length_limit:{"text":"A senha excedeu o limite!","color":"red"}, empty:{"text":"A senha não pode estar vazia!","color":"red"}, cleared:{"text":"Entrada limpa.","color":"green"}, wrong:{"text":"Senha incorreta!","color":"red"}}
