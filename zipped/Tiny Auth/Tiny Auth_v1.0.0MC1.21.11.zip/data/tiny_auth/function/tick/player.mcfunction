$execute unless data storage tiny_auth:keys auths[{UUID:$(UUID)}] run data modify storage tiny_auth:keys auths append value {UUID:$(UUID),password:"",input:""}

$execute if data storage tiny_auth:keys auths[{UUID:$(UUID),Name:""}] in tiny_auth:authdim run loot replace block 0 0 0 container.0 loot {type:"minecraft:chest",pools:[{rolls:1,entries:[{type:"minecraft:item",name:"minecraft:player_head",functions:[{function:"minecraft:fill_player_head",entity:"this"}]}]}],functions:[]}
$execute if data storage tiny_auth:keys auths[{UUID:$(UUID),Name:""}] in tiny_auth:authdim run data modify storage tiny_auth:keys auths[{UUID:$(UUID)}].Name set from block 0 0 0 Items[{Slot:0b}].components."minecraft:profile".name

execute unless score @s tinyauth.detection.leave_game matches 0 run function tiny_auth:tick/player/leave_game with entity @s

function tiny_auth:auth/keys with entity @s
