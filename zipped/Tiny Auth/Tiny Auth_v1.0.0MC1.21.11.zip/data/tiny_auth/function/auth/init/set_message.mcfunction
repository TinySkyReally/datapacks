$execute if data storage tiny_auth:languages {$(language):{$(message):{}}} run return run data modify storage tiny_auth:temp show_dialog.message set from storage tiny_auth:languages $(language).$(message)

$execute if data storage tiny_auth:languages {en-us:{$(message):{}}} run return run data modify storage tiny_auth:temp show_dialog.message set from storage tiny_auth:languages en-us.$(message)

data modify storage tiny_auth:temp show_dialog.message set value {"text":""}
