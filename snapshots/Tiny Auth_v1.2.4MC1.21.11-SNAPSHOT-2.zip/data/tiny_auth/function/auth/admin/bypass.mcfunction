$execute unless entity @a[name=$(Name)] run return run tellraw @s [{text:"This player isn't online!",color:"red"}]

$data modify storage tiny_auth:temp bypass set from storage tiny_auth:keys auths[{Name:$(Name)}]

$execute as $(Name) run function tiny_auth:auth/reset
$execute as $(Name) run function tiny_auth:auth/success with storage tiny_auth:temp bypass
$dialog clear $(Name)

$tellraw @s [{text:"Successfully bypassed player $(Name)!",color:"green"}]
