scoreboard players reset @s tinyauth.auth.submit

$data modify storage tiny_auth:temp auth set from storage tiny_auth:keys auths[{UUID:$(UUID)}]

$execute if score @s tinyauth.auth.state matches 3 store result score @s tinyauth.auth.temp run data get storage tiny_auth:keys auths[{UUID:$(UUID)}].time
execute if score @s tinyauth.auth.state matches 3 store result score #time tinyauth.auth.temp run time query gametime
$execute if score @s tinyauth.auth.state matches 3 if score @s tinyauth.auth.temp >= #time tinyauth.auth.temp run return run function tiny_auth:auth/init {UUID:$(UUID),message:"blocked",submit:"",state:3}

execute store result score #input tinyauth.auth.temp run data get storage tiny_auth:temp auth.input
execute store result score #max_password_length tinyauth.auth.temp run data get storage tiny_auth:config max_password_length
$execute if score #input tinyauth.auth.temp > #max_password_length tinyauth.auth.temp run data modify storage tiny_auth:temp maxPasswordLength set value {UUID:$(UUID),message:"length_limit",submit:"",state:1}
execute if score #input tinyauth.auth.temp > #max_password_length tinyauth.auth.temp store result storage tiny_auth:temp maxPasswordLength.state int 1 run scoreboard players get @s tinyauth.auth.state
execute if score #input tinyauth.auth.temp > #max_password_length tinyauth.auth.temp run function tiny_auth:auth/init with storage tiny_auth:temp maxPasswordLength

execute if score @s tinyauth.auth.state matches 2 run function tiny_auth:auth/reset
execute if score @s tinyauth.auth.state matches 2 run tellraw @s [{"text":"[Tiny Auth]: Sucesfully changed password!","color":"green"}]
$execute if score @s tinyauth.auth.state matches 2 run data modify storage tiny_auth:keys auths[{UUID:$(UUID)}].password set from storage tiny_auth:temp auth.input
execute if score @s tinyauth.auth.state matches 2 run return run function tiny_auth:auth/success with storage tiny_auth:temp auth

execute if data storage tiny_auth:temp {auth:{password:""}} unless data storage tiny_auth:temp {auth:{input:""}} run function tiny_auth:auth/reset
execute if data storage tiny_auth:temp {auth:{password:""}} unless data storage tiny_auth:temp {auth:{input:""}} run function tiny_auth:auth/success with storage tiny_auth:temp auth
execute if data storage tiny_auth:temp {auth:{password:""}} unless data storage tiny_auth:temp {auth:{input:""}} run tellraw @s [{"text":"[Tiny Auth]: Sucesfully registered!","color":"green"}]
$execute if data storage tiny_auth:temp {auth:{password:""}} unless data storage tiny_auth:temp {auth:{input:""}} run return run data modify storage tiny_auth:keys auths[{UUID:$(UUID)}].password set from storage tiny_auth:keys auths[{UUID:$(UUID)}].input

execute unless data storage tiny_auth:temp {auth:{password:""}} unless function tiny_auth:auth/check/test run function tiny_auth:auth/reset
execute unless data storage tiny_auth:temp {auth:{password:""}} unless function tiny_auth:auth/check/test run function tiny_auth:auth/success with storage tiny_auth:temp auth
execute unless data storage tiny_auth:temp {auth:{password:""}} unless function tiny_auth:auth/check/test run return run tellraw @s [{"text":"[Tiny Auth]: Sucesfully logged in!","color":"green"}]

function tiny_auth:auth/reset_input with entity @s
execute unless data storage tiny_auth:temp {auth:{input:""}} run function tiny_auth:auth/wrong_password with entity @s
$execute if data storage tiny_auth:temp {auth:{input:""}} run function tiny_auth:auth/init {UUID:$(UUID),message:"empty",submit:"",state:1}

#$execute unless data storage tiny_auth:keys auths[{UUID:$(UUID)}] run data modify storage tiny_auth:keys auths append value {UUID:$(UUID),password:"",input:""}
