$data modify storage tiny_auth:temp enter_get.input set from storage tiny_auth:keys auths[{UUID:$(UUID)}].input
execute unless data storage tiny_auth:temp enter_get.input run data modify storage tiny_auth:temp enter_get.input set value ""
