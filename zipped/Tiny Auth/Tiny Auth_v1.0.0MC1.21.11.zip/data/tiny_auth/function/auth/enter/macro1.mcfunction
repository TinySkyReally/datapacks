$data modify storage tiny_auth:temp inputSet set value "$(input)$(text)"

execute store result score #input tinyauth.auth.temp run data get storage tiny_auth:temp inputSet
execute store result score #max_password_length tinyauth.auth.temp run data get storage tiny_auth:config max_password_length
$execute unless score #input tinyauth.auth.temp > #max_password_length tinyauth.auth.temp run data modify storage tiny_auth:keys auths[{UUID:$(UUID)}].input set value "$(input)$(text)"

$data modify storage tiny_auth:temp initEnter set value {UUID:$(UUID),message:"",submit:-1,state:1}
execute store result storage tiny_auth:temp initEnter.state int 1 run scoreboard players get @s tinyauth.auth.state

function tiny_auth:auth/init with storage tiny_auth:temp initEnter
