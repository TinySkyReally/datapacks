scoreboard players reset @s tinyauth.auth.enter.1
scoreboard players reset @s tinyauth.auth.enter.2
scoreboard players reset @s tinyauth.auth.enter.3
scoreboard players reset @s tinyauth.auth.enter.4
scoreboard players reset @s tinyauth.auth.enter.5
scoreboard players reset @s tinyauth.auth.enter.6
scoreboard players reset @s tinyauth.auth.enter.7
scoreboard players reset @s tinyauth.auth.enter.8
scoreboard players reset @s tinyauth.auth.enter.9
scoreboard players reset @s tinyauth.auth.enter.0
scoreboard players reset @s tinyauth.auth.enter.q
scoreboard players reset @s tinyauth.auth.enter.w
scoreboard players reset @s tinyauth.auth.enter.e
scoreboard players reset @s tinyauth.auth.enter.r
scoreboard players reset @s tinyauth.auth.enter.t
scoreboard players reset @s tinyauth.auth.enter.y
scoreboard players reset @s tinyauth.auth.enter.u
scoreboard players reset @s tinyauth.auth.enter.i
scoreboard players reset @s tinyauth.auth.enter.o
scoreboard players reset @s tinyauth.auth.enter.p
scoreboard players reset @s tinyauth.auth.enter.a
scoreboard players reset @s tinyauth.auth.enter.s
scoreboard players reset @s tinyauth.auth.enter.d
scoreboard players reset @s tinyauth.auth.enter.f
scoreboard players reset @s tinyauth.auth.enter.g
scoreboard players reset @s tinyauth.auth.enter.h
scoreboard players reset @s tinyauth.auth.enter.j
scoreboard players reset @s tinyauth.auth.enter.k
scoreboard players reset @s tinyauth.auth.enter.l
scoreboard players reset @s tinyauth.auth.enter.z
scoreboard players reset @s tinyauth.auth.enter.x
scoreboard players reset @s tinyauth.auth.enter.c
scoreboard players reset @s tinyauth.auth.enter.v
scoreboard players reset @s tinyauth.auth.enter.b
scoreboard players reset @s tinyauth.auth.enter.n
scoreboard players reset @s tinyauth.auth.enter.m

scoreboard players reset @s tinyauth.auth.submit
scoreboard players reset @s tinyauth.auth.clear

attribute @s minecraft:block_break_speed base reset
attribute @s minecraft:attack_damage base reset
attribute @s minecraft:movement_speed base reset
attribute @s minecraft:jump_strength base reset
attribute @s minecraft:block_interaction_range base reset
attribute @s minecraft:entity_interaction_range base reset

effect clear @s minecraft:blindness
effect clear @s minecraft:resistance
