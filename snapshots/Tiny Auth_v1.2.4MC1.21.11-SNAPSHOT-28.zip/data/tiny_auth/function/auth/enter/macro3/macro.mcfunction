#function tiny_auth:auth/enter {key:"a",text:"A"}
#id

$data modify storage tiny_auth:temp enter_get.text set from storage tiny_auth:storage character_map."$(id)"
data modify storage tiny_auth:temp enter_get.UUID set from entity @s UUID

#$say $(id)
