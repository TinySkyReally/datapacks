execute if data storage tiny_auth:config admin.lockout_duration run data modify storage tiny_auth:config lockout_duration set from storage tiny_auth:config admin.lockout_duration
execute if data storage tiny_auth:config admin.max_attempts run data modify storage tiny_auth:config max_attempts set from storage tiny_auth:config admin.max_attempts
execute if data storage tiny_auth:config admin.lock_attempts run data modify storage tiny_auth:config lock_attempts set from storage tiny_auth:config admin.lock_attempts
execute if data storage tiny_auth:config admin.max_password_length run data modify storage tiny_auth:config max_password_length set from storage tiny_auth:config admin.max_password_length
execute if data storage tiny_auth:config admin.theme run data modify storage tiny_auth:config theme set from storage tiny_auth:config admin.theme
execute if data storage tiny_auth:config admin.language run data modify storage tiny_auth:config language set from storage tiny_auth:config admin.language

data modify storage tiny_auth:config theme_id set from storage tiny_auth:visuals themes[{name:"$(theme)"}].id
data modify storage tiny_auth:config language_id set from storage tiny_auth:visuals languages[{name:"$(language)"}].id
