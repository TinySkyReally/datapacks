#item -1, UUID
$data modify storage tiny_auth:temp PasswordContainsLoop.loopitem set string storage tiny_auth:keys auths[{UUID:$(UUID)}].input $(item)
$data modify storage tiny_auth:temp PasswordContainsLoop.UUID set value $(UUID)

data remove storage tiny_auth:temp PasswordContainsLoop.chartype
function tiny_auth:auth/check/contains/macro with storage tiny_auth:temp PasswordContainsLoop
$execute if data storage tiny_auth:temp PasswordContainsLoop.chartype if data storage tiny_auth:temp {PasswordContainsLoop:{chartype:"Number"}} run data modify storage tiny_auth:keys auths[{UUID:$(UUID)}].input_contains_number set value 1b
$execute if data storage tiny_auth:temp PasswordContainsLoop.chartype if data storage tiny_auth:temp {PasswordContainsLoop:{chartype:"Letter"}} run data modify storage tiny_auth:keys auths[{UUID:$(UUID)}].input_contains_letter set value 1b
$execute if data storage tiny_auth:temp PasswordContainsLoop.chartype if data storage tiny_auth:temp {PasswordContainsLoop:{chartype:"Symbol"}} run data modify storage tiny_auth:keys auths[{UUID:$(UUID)}].input_contains_symbol set value 1b

$scoreboard players set #PasswordContainsLoop tinyauth.auth.temp $(item)
scoreboard players remove #PasswordContainsLoop tinyauth.auth.temp 1
execute if score #PasswordContainsLoop tinyauth.auth.temp matches ..-1 run return 0

execute store result storage tiny_auth:temp PasswordContainsLoop.item int 1 run scoreboard players get #PasswordContainsLoop tinyauth.auth.temp

function tiny_auth:auth/check/contains with storage tiny_auth:temp PasswordContainsLoop
