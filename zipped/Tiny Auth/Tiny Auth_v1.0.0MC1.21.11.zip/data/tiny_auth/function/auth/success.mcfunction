$execute in $(dimension) run tp $(x) $(y) $(z)
$gamemode $(gamemode)
scoreboard players set @s tinyauth.auth.state 0
scoreboard players enable @s tinyauth.auth.change_password
scoreboard players enable @s tinyauth.auth.logout