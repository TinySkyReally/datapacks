function tiny_auth:debug/send_info/with_me {info:{"text":"Fresh installation detected! Initializing framework...","color":"gray"}}

#Features

data modify storage tiny_auth:datapack version set value "1.2.4"
