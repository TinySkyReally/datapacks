$data modify storage tiny_auth:temp show_dialog.message set value [$(message),{"text":"$(timeLeft)s."}]
