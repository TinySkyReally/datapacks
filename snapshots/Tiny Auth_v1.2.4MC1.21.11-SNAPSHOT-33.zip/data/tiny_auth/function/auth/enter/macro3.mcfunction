#function tiny_auth:auth/enter {key:"a",text:"A"}

execute store result storage tiny_auth:temp enter_get.id int 1 run scoreboard players get @s tinyauth.auth.enter
scoreboard players reset @s tinyauth.auth.enter

execute if score @s tinyauth.auth.gui_opened matches 0 run return run tellraw @s [{text:"You cannot use this command right now!",color:"red"}]

function tiny_auth:auth/enter/macro3/macro with storage tiny_auth:temp enter_get
function tiny_auth:auth/enter/macro3/fetch_input with storage tiny_auth:temp enter_get
function tiny_auth:auth/enter/macro with storage tiny_auth:temp enter_get
